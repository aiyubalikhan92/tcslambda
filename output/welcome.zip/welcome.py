def hello(event, context):
    print("AN MEAN NASIB")