def test(event, context):
    print("AN MEAN NASIB")